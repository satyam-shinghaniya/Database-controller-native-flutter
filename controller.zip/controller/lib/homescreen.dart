import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const platform = MethodChannel('com.example.controller');

  final _firstTextFieldController = TextEditingController();
  final _lastTextFieldController = TextEditingController();
  List<Map<String, dynamic>> usersList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Geolocation App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () async {
                await getAllUsers();
              },
              child: Text('Get All Users'),
            ),
            ElevatedButton(
              onPressed: () async {
                await _showTextInputDialog(context);
              },
              child: Text('Insert User'),
            ),
            if (usersList.isNotEmpty)
              Column(
                children: usersList
                    .map((user) => Text('UID: ${user['uid']}, Name: ${user['firstName']} ${user['lastName']}'))
                    .toList(),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> getAllUsers() async {
    try {
      final List<dynamic> users = await platform.invokeMethod('getAllUsers');
      setState(() {
        usersList = users.map((user) => Map<String, dynamic>.from(user)).toList();
      });
      print('Users retrieved: $usersList');
    } on PlatformException catch (e) {
      print("Failed to get users: '${e.message}'.");
    }
  }

  Future<void> _showTextInputDialog(BuildContext context) async {
    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Insert User'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _firstTextFieldController,
                decoration: const InputDecoration(hintText: "First Name"),
              ),
              TextField(
                controller: _lastTextFieldController,
                decoration: const InputDecoration(hintText: "Last Name"),
              ),
            ],
          ),
          actions: <Widget>[
            ElevatedButton(
              child: const Text('Cancel'),
              onPressed: () {
                _firstTextFieldController.clear();
                _lastTextFieldController.clear();
                Navigator.pop(context);
              },
            ),
            ElevatedButton(
              child: const Text('OK'),
              onPressed: () async {
                final String firstName = _firstTextFieldController.text;
                final String lastName = _lastTextFieldController.text;
                Navigator.pop(context);
                _firstTextFieldController.clear();
                _lastTextFieldController.clear();
                try {
                  await platform.invokeMethod('insertUser', {
                    'uid': usersList.length + 1,
                    'firstName': firstName,
                    'lastName': lastName,
                  });
                  print('User inserted: $firstName $lastName');
                } on PlatformException catch (e) {
                  print("Failed to insert user: '${e.message}'.");
                }
              },
            ),
          ],
        );
      },
    );
  }
}
