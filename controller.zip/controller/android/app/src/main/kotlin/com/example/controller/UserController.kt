package com.example.controller

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserController(private val context: Context) {
    private val userDao = DatabaseClient.getDatabase(context).userDao()

    suspend fun getAllUsers(): List<User> = withContext(Dispatchers.IO) {
        userDao.getAll()
    }

    suspend fun insertUser(user: User) = withContext(Dispatchers.IO) {
        userDao.insertAll(user)
    }
}
