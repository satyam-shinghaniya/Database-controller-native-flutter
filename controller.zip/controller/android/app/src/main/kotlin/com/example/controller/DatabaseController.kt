package com.example.controller

import android.content.Context

class DatabaseController(context: Context) {
   /*// private val database = AppDatabase.getDatabase(context)
    private val locationDao = database.locationDao()

    suspend fun insertLocation(latitude: Double, longitude: Double) {
        val location = LocationEntity(latitude = latitude, longitude = longitude)
        locationDao.insert(location)
    }

    suspend fun getAllLocations(): List<LocationEntity> {
        return locationDao.getAllLocations()
    }

    suspend fun deleteLocation(location: LocationEntity) {
        locationDao.delete(location)
    }*/
}
