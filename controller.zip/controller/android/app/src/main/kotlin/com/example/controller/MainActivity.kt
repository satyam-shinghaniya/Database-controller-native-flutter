package com.example.controller

import android.os.Bundle
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.example.controller"
    private val userController by lazy { UserController(applicationContext) }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "getAllUsers" -> {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val users = userController.getAllUsers()
                            val userList = users.map {
                                mapOf("uid" to it.uid, "firstName" to it.firstName, "lastName" to it.lastName)
                            }
                            withContext(Dispatchers.Main) {
                                result.success(userList)
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                result.error("UNAVAILABLE", "Database error: ${e.message}", null)
                            }
                        }
                    }
                }
                "insertUser" -> {
                    val uid = call.argument<Int>("uid")!!
                    val firstName = call.argument<String>("firstName")!!
                    val lastName = call.argument<String>("lastName")!!
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            userController.insertUser(User(uid, firstName, lastName))
                            withContext(Dispatchers.Main) {
                                result.success(null)
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                result.error("UNAVAILABLE", "Database error: ${e.message}", null)
                            }
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
